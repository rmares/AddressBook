﻿namespace AddressBook.Application.Contacts.DTOs
{
    public class ContactPhoneDto
    {
        public int Id { get; set; }
        public string PhoneNumber { get; set; }
    }
}