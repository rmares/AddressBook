import Axios, { AxiosRequestConfig } from "axios";

export default class ApiClient {
  constructor() {
    Axios.defaults.baseURL = process.env.REACT_APP_TR_API_BASE_URL;
  }

  async get(url: string) {
    const response = await Axios.get(url);
    return response.data;
  }

  async post(url: string, data: any) {
    const response = await Axios.post(url, data);
    return response.data;
  }

  async put(url: string, data: any) {
    const response = await Axios.put(url, data);
    return response.data;
  }

  async delete(url: string) {
    const response = await Axios.delete(url);
  }
}
