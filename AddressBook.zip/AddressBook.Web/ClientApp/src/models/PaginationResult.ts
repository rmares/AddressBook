export default interface PaginationResult<T> {
  count: number;
  data: T[];
}
