import React, { useState } from "react";

const useTable = () => {
  const [page, setPage] = useState(0);
  const [pageSize, setpageSize] = useState(50);

  const handleChangePage = (
    event: React.MouseEvent<HTMLButtonElement, MouseEvent> | null,
    newPage: number
  ) => {
    setPage(newPage);
  };

  const handleChangepageSize = (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setpageSize(parseInt(event.target.value, 10));
    setPage(0);
  };

  return {
    page,
    pageSize,
    handleChangePage,
    handleChangepageSize
  };
};

export default useTable;
