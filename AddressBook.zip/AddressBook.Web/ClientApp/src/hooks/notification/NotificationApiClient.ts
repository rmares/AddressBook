import ApiClient from "../../api/ApiClient";
import Notification from "./Notification";

export default class NotificationApiClient {
  apiClient: ApiClient;
  urlPrefix: string = "notifications/";

  constructor() {
    this.apiClient = new ApiClient();
  }

  async getUnreadAndRecentNotifications() {
    const notifications = await this.apiClient.get(`${this.urlPrefix}push`);

    return notifications as Notification[];
  }

  async markNotificationsAsReaded(notificationIds: number[]) {
    await this.apiClient.put(`${this.urlPrefix}push/read`, {
      notificationIds: notificationIds
    });
  }
}
