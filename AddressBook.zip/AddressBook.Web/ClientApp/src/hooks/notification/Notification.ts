export default interface Notification {
  id: number;
  date: Date;
  message: string;
  isReaded: boolean;
}
