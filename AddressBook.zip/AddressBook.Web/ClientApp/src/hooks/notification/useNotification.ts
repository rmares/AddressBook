import { useEffect, useState } from "react";
import { HubConnection, HubConnectionBuilder } from "@aspnet/signalr";
import Notification from "./Notification";
import NotificationApiClient from "./NotificationApiClient";

interface Props {
  hubUrl: string;
  accessToken?: string;
}

const useNotification = ({ hubUrl, accessToken }: Props) => {
  const [hubConnection, setHubConnection] = useState(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const apiClient = new NotificationApiClient();

  useEffect(() => {
    initializeAndSetConnection();
    fetchAndSetNotifications();
  }, []);

  const initializeAndSetConnection = () => {
    const connection = new HubConnectionBuilder().withUrl(hubUrl).build();

    connection.on(
      "ReceiveNotification",
      (receivedNotification: Notification) => {
        setNotifications((previousState: Notification[]) => [
          receivedNotification,
          ...previousState
        ]);
      }
    );

    connection.onclose(function() {
      setTimeout(function() {
        startConnection(connection);
      }, 60000);
    });

    startConnection(connection);
    setHubConnection(hubConnection);
  };

  const startConnection = (connection: HubConnection) => {
    connection
      .start()
      .then(() => console.log("Hub connection started!"))
      .catch(err => console.log("Error while establishing hub connection!"));
  };

  const fetchAndSetNotifications = async () => {
    const notifications = await apiClient.getUnreadAndRecentNotifications();

    setNotifications(notifications);
  };

  const markNotificationsAsReaded = async () => {
    const unreadNotificationIds = notifications
      .filter(n => !n.isReaded)
      .map((n, i) => {
        return n.id;
      });

    if (unreadNotificationIds && unreadNotificationIds.length > 0) {
      await apiClient.markNotificationsAsReaded(unreadNotificationIds);
      fetchAndSetNotifications();
    }
  };

  return {
    notifications,
    markNotificationsAsReaded
  };
};

export default useNotification;
