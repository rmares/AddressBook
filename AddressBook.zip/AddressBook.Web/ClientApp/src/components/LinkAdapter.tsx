import React from "react";
import { LinkProps, NavLink } from "react-router-dom";
import { makeStyles } from "@material-ui/styles";

const LinkAdapter = React.forwardRef<HTMLAnchorElement, LinkProps>(
  (props, ref) => {
    const classes = useStyles();

    return (
      <NavLink innerRef={ref} {...props} activeClassName={classes.activeLink} />
    );
  }
);

export default LinkAdapter;

const useStyles = makeStyles({
  activeLink: {
    backgroundColor: "#002444"
  }
});
