import React, { useContext, useState } from "react";
import {
  Badge,
  IconButton,
  Toolbar,
  Typography,
  Menu,
  MenuItem,
  Box
} from "@material-ui/core";
import AppBar from "@material-ui/core/AppBar";
import { makeStyles } from "@material-ui/core/styles";
import NotificationsIcon from "@material-ui/icons/Notifications";
import useNotification from "../hooks/notification/useNotification";
import { notificationHubUrl } from "../app/apiUrls";

const useStyles = makeStyles(theme => ({
  appBar: {
    zIndex: theme.zIndex.drawer + 1,
    transition: theme.transitions.create(["width", "margin"], {
      easing: theme.transitions.easing.sharp,
      duration: theme.transitions.duration.leavingScreen
    })
  },
  toolbar: {
    paddingRight: 24
  },
  title: {
    flexGrow: 1,
    marginLeft: "5px"
  },
  menuContainer: {
    border: "1px solid #e0e0e0;"
  }
}));

export default function Header() {
  const classes = useStyles({});
  const [anchorElement, setAnchorElement] = useState<null | HTMLElement>(null);
  const { notifications, markNotificationsAsReaded } = useNotification({
    hubUrl: notificationHubUrl()
  });
  const isNotificationsMenuOpen = Boolean(anchorElement);

  const handleNotificationMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    if (notifications.length > 0) {
      setAnchorElement(event.currentTarget);
    }
  };

  const handleNotificationMenuClose = () => {
    setAnchorElement(null);
    markNotificationsAsReaded();
  };

  const renderNotificationMenu = (
    <Menu
      elevation={0}
      getContentAnchorEl={null}
      anchorEl={anchorElement}
      anchorOrigin={{
        vertical: "bottom",
        horizontal: "center"
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "center"
      }}
      keepMounted
      classes={{ paper: classes.menuContainer }}
      open={isNotificationsMenuOpen}
      onClose={handleNotificationMenuClose}
    >
      <div>
        {notifications.map((n, i) => (
          <MenuItem key={i}>
            <Box
              fontSize="body2.fontSize"
              fontWeight={n.isReaded ? "fontWeightRegular" : "fontWeightBold"}
            >
              <Box fontSize="caption.fontSize">{n.date}</Box>
              {n.message}
            </Box>
          </MenuItem>
        ))}
      </div>
    </Menu>
  );

  const getUnreadNotificationsCount = () => {
    return notifications.filter(n => !n.isReaded).length;
  };

  return (
    <AppBar position="absolute" className={classes.appBar}>
      <Toolbar className={classes.toolbar}>
        <Typography
          variant="body2"
          color="inherit"
          noWrap
          className={classes.title}
        >
          Address Book
        </Typography>
        <IconButton
          edge="end"
          color="inherit"
          onClick={handleNotificationMenuOpen}
        >
          <Badge badgeContent={getUnreadNotificationsCount()} color="secondary">
            <NotificationsIcon />
          </Badge>
        </IconButton>
      </Toolbar>
      {renderNotificationMenu}
    </AppBar>
  );
}
