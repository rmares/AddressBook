export default interface TableBodyData {
  readonly idDataName: string;
  readonly data: any[] | null;
}
