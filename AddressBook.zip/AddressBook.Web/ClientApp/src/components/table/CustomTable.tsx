import React, { useState, Fragment, ReactElement } from "react";
import {
  TableHead,
  TableRow,
  TableCell,
  Table,
  TableBody,
  Checkbox,
  makeStyles,
  TablePagination,
  TableFooter,
  Typography
} from "@material-ui/core";
import TableHeadMetadata from "./TableHeadMetadata";
import TableBodyData from "./TableBodyData";

const useStyles = makeStyles(theme => ({
  tableCell: {
    padding: "14px 16px 14px 16px"
  },
  tableHead: {
    color: "#1c1c1c",
    fontSize: "0.875rem",
    padding: "14px 16px 14px 16px"
  },
  messageCell: {
    padding: "20px",
    fontSize: "1.25rem",
    textAlign: "center"
  },
  disabledBg: {
    background: "#F5F5F5"
  }
}));

interface Props {
  headMetadata: TableHeadMetadata<any>[];
  bodyData: TableBodyData;
  enableSelect?: boolean;
  enableAllSelect?: boolean;
  hover?: boolean;
  preSelectedIds?: string[];
  disabledIds?: string[];
  onSelectChange?: (selectedIds: string[]) => void;
  enablePagination?: boolean;
  page?: number;
  pageSize?: number;
  totalCount?: number;
  onChangePage?: (
    event: React.MouseEvent<HTMLButtonElement, MouseEvent> | null,
    newPage: number
  ) => void;
  onChangePageSize?: (
    event: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => void;
  noDataMessage?: string;
  onBodyRowCreated?: (tableRow: ReactElement, rowData: any) => void;
  onBodyCellCreated?: (
    tableRow: ReactElement,
    rowData: any,
    cellData: any,
    headMetadata?: TableHeadMetadata<any>
  ) => void;
}

export default function TrTable({
  headMetadata,
  bodyData,
  enableSelect = false,
  enableAllSelect = false,
  hover = false,
  preSelectedIds,
  disabledIds = [],
  onSelectChange,
  enablePagination,
  page,
  pageSize,
  totalCount,
  onChangePage,
  onChangePageSize,
  noDataMessage,
  onBodyRowCreated,
  onBodyCellCreated
}: Props) {
  const classes = useStyles({});
  const [selectedIds, setSelectedIds] = useState<string[]>(
    preSelectedIds != null ? preSelectedIds : []
  );

  const handleAllClick = (event: React.ChangeEvent<HTMLInputElement>) => {
    let ids = new Array<string>();
    if (event.target.checked && bodyData.data != null) {
      bodyData.data.forEach(d => {
        if (
          disabledIds.filter(
            disabledId => disabledId == d[bodyData.idDataName].toString()
          ).length == 0
        ) {
          ids.push(d[bodyData.idDataName].toString());
        }
      });
    }
    setSelectedIds(ids);

    if (onSelectChange) {
      onSelectChange(ids);
    }
  };

  const handleSingleClick = (
    event: React.ChangeEvent<HTMLInputElement>,
    selectedId: string
  ) => {
    let ids = [...selectedIds];

    if (event.target.checked) {
      ids.push(selectedId);
    } else {
      ids = ids.filter(value => value !== selectedId);
    }

    setSelectedIds(ids);

    if (onSelectChange) {
      onSelectChange(ids);
    }
  };

  const generateBodyRow = (rowData: any) => {
    return (
      <TableRow
        hover={hover}
        key={rowData[bodyData.idDataName]}
        className={
          disabledIds.includes(rowData[bodyData.idDataName].toString())
            ? " " + classes.disabledBg
            : ""
        }
      >
        {headMetadata.map((headData, index) => {
          let cellKey = index + rowData[bodyData.idDataName];
          let cellData =
            headData.dataFunc! != null
              ? headData.dataFunc!(rowData)
              : rowData[headMetadata[index].dataName!];
          let cellDataId = rowData[bodyData.idDataName].toString();

          if (enableSelect === true && index === 0) {
            return (
              <Fragment key={cellKey}>
                <TableCell padding="checkbox">
                  <Checkbox
                    checked={
                      selectedIds.includes(cellDataId) &&
                      !disabledIds.includes(cellDataId)
                    }
                    disabled={disabledIds.includes(cellDataId)}
                    onChange={event => handleSingleClick(event, cellDataId)}
                  />
                </TableCell>
                {generateBodyCell(cellKey, rowData, cellData, headData)}
              </Fragment>
            );
          } else {
            return generateBodyCell(cellKey, rowData, cellData, headData);
          }
        })}
      </TableRow>
    );
  };

  const generateBodyCell = (
    key: any,
    rowData: any,
    cellData: any,
    headMetadata: TableHeadMetadata<any>
  ) => {
    let cellDataId = rowData[bodyData.idDataName].toString();
    let cell = (
      <TableCell key={key} className={classes.tableCell}>
        <Typography
          variant="body2"
          color={disabledIds.includes(cellDataId) ? "textSecondary" : "inherit"}
          component="div"
        >
          {cellData}
        </Typography>
      </TableCell>
    );
    if (onBodyCellCreated) {
      return onBodyCellCreated(cell, rowData, cellData, headMetadata);
    }

    return cell;
  };

  let head = (
    <TableRow>
      {headMetadata.map((data, index) => {
        let cell = (
          <TableCell className={classes.tableHead} key={data.id}>
            {data.label}
          </TableCell>
        );
        if (enableSelect && index === 0) {
          return (
            <Fragment key={data.id}>
              <TableCell padding={enableAllSelect ? "checkbox" : "default"}>
                {enableAllSelect ? (
                  <Checkbox
                    checked={
                      bodyData.data != null &&
                      bodyData.data.length - disabledIds.length ===
                        selectedIds.length
                    }
                    disabled={
                      bodyData.data != null &&
                      bodyData.data.length === disabledIds.length
                    }
                    onChange={handleAllClick}
                  />
                ) : null}
              </TableCell>
              {cell}
            </Fragment>
          );
        } else {
          return cell;
        }
      })}
    </TableRow>
  );

  let body = null;
  if (bodyData.data != null && bodyData.data.length > 0) {
    body = bodyData.data.map(rowData => {
      let bodyRow = generateBodyRow(rowData);
      if (onBodyRowCreated) {
        return onBodyRowCreated(bodyRow, rowData);
      }
      return bodyRow;
    });
  } else if (noDataMessage) {
    body = (
      <TableRow>
        <TableCell
          colSpan={headMetadata.length}
          className={classes.messageCell}
        >
          {noDataMessage}
        </TableCell>
      </TableRow>
    );
  }

  let footer = (
    <TableRow>
      <TablePagination
        colSpan={headMetadata.length}
        page={page || 0}
        rowsPerPage={pageSize || 0}
        count={totalCount || 0}
        labelRowsPerPage={""}
        labelDisplayedRows={({ from, to, count }) => `${from}-${to} (${count})`}
        onChangePage={onChangePage || (() => {})}
        onChangeRowsPerPage={onChangePageSize || (() => {})}
      />
    </TableRow>
  );

  return (
    <Table size="medium">
      <TableHead>{head}</TableHead>
      <TableBody>{body}</TableBody>
      {enablePagination ? <TableFooter>{footer}</TableFooter> : null}
    </Table>
  );
}
