export default interface TableHeadMetadata<T> {
  readonly id: string;
  readonly label: string;
  readonly dataName?: keyof T;
  readonly dataFunc?: (d: T) => any;
}
