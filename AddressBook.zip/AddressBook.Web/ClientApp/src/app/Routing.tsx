import React, { useContext } from "react";
import { Switch, Route } from "react-router";
import ContactListPage from "../contacts/ContactListPage";
import ContactPage from "../contacts/ContactPage";
import { contactsUrl, contactNewUrl, contactEditUrl } from "./urls";

export default function Routing() {
  return (
    <Switch>
      <Route exact path={["/", contactsUrl()]} component={ContactListPage} />
      <Route exact path={contactNewUrl()} component={ContactPage} />
      <Route exact path={contactEditUrl()} component={ContactPage} />
    </Switch>
  );
}
