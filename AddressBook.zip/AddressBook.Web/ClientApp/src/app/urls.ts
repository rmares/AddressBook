export const contactsUrl = (): string => "/contacts";
export const contactNewUrl = (): string => "/contacts/new";
export const contactEditUrl = (id?: string): string =>
  `/contacts/${id ? id : ":id"}/edit`;
