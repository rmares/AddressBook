import React from "react";
import { makeStyles, Container } from "@material-ui/core";
import Header from "../components/Header";
import Routing from "./Routing";

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    backgroundColor: "#f4f6f8"
  },
  content: {
    flexGrow: 1,
    height: "100vh",
    overflow: "auto"
  },
  appBarSpacer: theme.mixins.toolbar,
  container: {
    paddingTop: theme.spacing(4),
    paddingBottom: theme.spacing(4)
  }
}));

const App: React.FC = () => {
  const classes = useStyles({});

  return (
    <div className={classes.root}>
      <Header />
      <main className={classes.content}>
        <div className={classes.appBarSpacer} />
        <Container maxWidth="xl" className={classes.container}>
          <Routing />
        </Container>
      </main>
    </div>
  );
};

export default App;
