const apiBaseUrl = process.env.REACT_APP_TR_API_BASE_URL;

export const notificationHubUrl = (): string =>
  `${apiBaseUrl}/hubs/notification`;
