import React, { useState, useEffect } from "react";
import { RouteComponentProps } from "react-router-dom";
import {
  Button,
  Paper,
  Grid,
  makeStyles,
  Typography,
  Divider
} from "@material-ui/core";
import { Add as AddIcon } from "@material-ui/icons";
import useTable from "../hooks/table/useTable";
import LinkAdapter from "../components/LinkAdapter";
import CustomTable from "../components/table/CustomTable";
import PaginationResult from "../models/PaginationResult";
import TableHeadMetadata from "../components/table/TableHeadMetadata";
import TableBodyData from "../components/table/TableBodyData";
import Contact from "./Contact";
import ContactApiClient from "./ContactApiClient";
import { contactNewUrl, contactEditUrl } from "../app/urls";
import { string } from "prop-types";

const useStyles = makeStyles(theme => ({
  root: {
    flexGrow: 1
  },
  button: {
    textTransform: "none"
  },
  itemRightAlign: {
    textAlign: "right"
  }
}));

export default function ContactListPage() {
  const classes = useStyles({});
  const [contactsPaged, setContactsPaged] = useState<PaginationResult<Contact>>(
    {} as PaginationResult<Contact>
  );
  const { page, pageSize, handleChangePage, handleChangepageSize } = useTable();

  useEffect(() => {
    search();
  }, [page, pageSize]);

  async function search() {
    const apiClient = new ContactApiClient();
    const requests = await apiClient.search(page + 1, pageSize);

    setContactsPaged(requests);
  }

  const tableHeadMetadata: TableHeadMetadata<Contact>[] = [
    { id: "id", label: "ID", dataName: "id" },
    { id: "name", label: "Name", dataName: "name" },
    { id: "address", label: "Address", dataName: "address" },
    {
      id: "phones",
      label: "Phones",
      dataFunc: (c: Contact) => {
        let phones = "";
        for (let index = 0; index < c.phones.length; index++) {
          phones += c.phones[index];
          if (index !== c.phones.length - 1) {
            phones += ", ";
          }
        }
      }
    }
  ];

  const tableBodyData: TableBodyData = {
    idDataName: "id",
    data: contactsPaged.data
  };

  return (
    <div className={classes.root}>
      <Grid container spacing={2}>
        <Grid item sm={12}>
          <Typography variant="h5">Contacts</Typography>
        </Grid>
        <Grid item sm={12}>
          <Button
            variant="contained"
            color="primary"
            className={classes.button}
            component={LinkAdapter}
            to={contactNewUrl()}
          >
            <AddIcon />
            Add
          </Button>
        </Grid>
        <Grid item xs={12}>
          <Divider />
        </Grid>
        <Grid item lg={12}>
          <Paper>
            <CustomTable
              hover={true}
              headMetadata={tableHeadMetadata}
              bodyData={tableBodyData}
              enablePagination={true}
              page={page}
              pageSize={pageSize}
              totalCount={contactsPaged.count}
              noDataMessage={"No contacts"}
              onChangePage={handleChangePage}
              onChangePageSize={handleChangepageSize}
            />
          </Paper>
        </Grid>
      </Grid>
    </div>
  );
}
