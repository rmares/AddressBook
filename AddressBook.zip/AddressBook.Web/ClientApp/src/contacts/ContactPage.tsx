import React from "react";

export default function ContactListPage() {
  return <div></div>;
}
