import ApiClient from "../api/ApiClient";
import PaginationResult from "../models/PaginationResult";
import Contact from "./Contact";

export default class ContactApiClient {
  apiClient: ApiClient;
  urlPrefix: string = "contacts/";

  constructor() {
    this.apiClient = new ApiClient();
  }

  async search(page?: number, pageItems?: number) {
    const requests = await this.apiClient.get(
      this.urlPrefix + `?pageNumber=${page}&pageSize=${pageItems}`
    );

    return requests as PaginationResult<Contact>;
  }

  async get(id: string) {
    const request = await this.apiClient.get(this.urlPrefix + `${id}`);

    return request as Contact;
  }

  async create(contact: Contact) {
    await this.apiClient.post(this.urlPrefix, contact);
  }

  async update(contact: Contact) {
    await this.apiClient.put(this.urlPrefix, contact);
  }

  async delete(id: number) {
    await this.apiClient.delete(this.urlPrefix + `${id}`);
  }
}
