import ContactPhone from "./ContactPhone";

export default interface Contact {
  id: number;
  name: string;
  address: string;
  phones: ContactPhone[];
}
