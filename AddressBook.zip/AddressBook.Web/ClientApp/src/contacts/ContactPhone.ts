export default interface ContactPhone {
  id: number;
  phoneNumber: string;
}
